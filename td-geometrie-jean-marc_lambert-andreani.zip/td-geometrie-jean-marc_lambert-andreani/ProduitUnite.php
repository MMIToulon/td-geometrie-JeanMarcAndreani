<?php
	require_once('Produit.php');
	abstract class Produit_Unite extends Produit
	{
		private $prix_kg;
		public function __construct($poids,$quantite)
		{
			echo "<br> Creation d'un produit unitaire";
			parent::__construct($poids,$quantite);
			$this->prix_unit = 2;
		}
		public function __toString()
		{
			return "<br> poids : ".$this->poids."<br> quantité : ".$this->quantite."<br> prix à l'unité : ".$this->prix_unit; 	
		}
		public function lire_Prix_unit()
		{
			return $this->prix_unit;
		}
		public function ecrire_Rayon($pu)
		{
			$this->prix_unit=$pu;
		}
		public function prix_unitaire()
		{
			return floor($this->quantite*$this->prix_unit);
		}
	}
?>