<?php
	ini_set('display_errors','1');
	require_once("ProduitUnite.php");
	$pk = new Produit_Unite();
	echo $pu;
	$pk->poids = 2 ;
	$pk->prix_unit = 1;
	echo $pu;
	$prix_u = $c->prix_unit();	
	echo "<br><br> Le prix est : ".$prix_unit;
?>