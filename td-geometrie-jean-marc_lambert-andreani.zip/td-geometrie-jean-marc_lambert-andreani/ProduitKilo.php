<?php
	require_once('Produit.php');
	abstract class Produit_Kilo extends Produit
	{
		private $prix_kg;
		public function __construct($poids,$quantite)
		{
			echo "<br> Creation d'un produit kilo";
			parent::__construct($poids,$quantite);
			$this->prix_kg = 1;
		}
		public function __toString()
		{
			return "<br> poids : ".$this->poids."<br> quantité : ".$this->quantite."<br> prix au kilo : ".$this->prix_kg; 	
		}
		public function lire_Prix_kg()
		{
			return $this->prix_kg;
		}
		public function ecrire_Rayon($p_kg)
		{
			$this->prix_kg=$p_kg;
		}
		public function prix_kilo()
		{
			return floor($this->poids*$this->prix_kg);
		}
	}
?>