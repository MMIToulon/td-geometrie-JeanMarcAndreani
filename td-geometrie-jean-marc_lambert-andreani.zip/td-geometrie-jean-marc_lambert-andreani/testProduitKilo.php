<?php
	ini_set('display_errors','1');
	require_once("ProduitKilo.php");
	$pk = new Produit_Kilo();
	echo $pk;
	$pk->poids = 2 ;
	$pk->prix_kg = 1;
	echo $pk;
	$prix_k = $c->prix_kilo();	
	echo "<br><br> Le prix est : ".$prix_kg;
?>