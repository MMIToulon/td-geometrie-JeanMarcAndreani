<?php 
	abstract class Produit 
	{
		protected $type = fruit;
		protected $poids = 3;
		protected $quantite = 2;
		public function __construct($poids, $quantite) 
		{
			echo "Construction d'un produit";
		}
		public function lire_poids()
		{
			return $this->poids;
		}
		public function ecrire_poids($poids)
		{
			$this->poids=$poids;
		}
		public function lire_quantite()
		{
			return $this->quantite;
		}
		public function ecrire_Y($quantite)
		{
			$this->quantite = $quantite;
		}
		public abstract function prix_kilo();   
		public abstract function prix_unitaire();   
	}

?>

